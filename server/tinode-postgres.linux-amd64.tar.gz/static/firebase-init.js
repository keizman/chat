const FIREBASE_INIT = {};
