// This is a generated file. Don't edit.

const PACKAGE_VERSION = "0.24.2";
